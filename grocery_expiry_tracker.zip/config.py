# Spoonacular API Configuration
SPOONACULAR_API_KEY = "YOUR_API_KEY_HERE"  # Replace with your actual API key
